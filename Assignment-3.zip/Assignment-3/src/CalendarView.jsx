import React, { useState } from "react";
import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css";
import "./CalendarView.css";

const CalendarView = () => {
  const [value, setValue] = useState(new Date());

  return (
    <div className="chart-like-calendar-container">
      <h2 className="calendar-title">📅 Calendar</h2>
      <div className="calendar-box">
        <Calendar
          onChange={setValue}
          value={value}
          tileClassName={({ date }) =>
            date.getDay() === 0 ? "highlight-sunday" : ""
          }
        />
      </div>
    </div>
  );
};

export default CalendarView;
