import React from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

const data = [
  { name: "Jan", sales: 400 },
  { name: "Feb", sales: 300 },
  { name: "Mar", sales: 500 },
  { name: "Apr", sales: 200 },
  { name: "May", sales: 450 },
  { name: "Jun", sales: 350 },
];

export default function ChartView() {
  return (
    <div
      style={{
        width: "100%",
        height: 300,
        backgroundColor: "var(--card-bg)",
        padding: 20,
        borderRadius: 6,
      }}
    >
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data}>
          <XAxis dataKey="name" stroke="var(--text)" />
          <YAxis stroke="var(--text)" />
          <Tooltip />
          <Bar dataKey="sales" fill="#8884d8" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
