import React, { useState, createContext, useContext } from "react";
import Dashboard from "./Dashboard";

// Create Theme Context
const ThemeContext = createContext();

export const useTheme = () => useContext(ThemeContext);

export default function App() {
  const [theme, setTheme] = useState("light");

  const toggleTheme = () =>
    setTheme((prev) => (prev === "light" ? "dark" : "light"));

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      <div className={theme === "light" ? "light-theme" : "dark-theme"}>
        <Dashboard />
      </div>
      <style>{`
        body, html, #root {
          margin: 0; padding: 0; height: 100%;
          font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .light-theme {
          --bg: #fff;
          --text: #222;
          --card-bg: #f8f9fa;
        }
        .dark-theme {
          --bg: #181818;
          --text: #eee;
          --card-bg: #282c34;
        }
        div {
          background-color: var(--bg);
          color: var(--text);
          min-height: 100vh;
          transition: all 0.3s ease;
        }
      `}</style>
    </ThemeContext.Provider>
  );
}
