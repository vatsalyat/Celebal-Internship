import React, { useState } from "react";

const initialData = [
  { id: 1, name: "Alice", role: "Admin", age: 29 },
  { id: 2, name: "Bob", role: "Editor", age: 34 },
  { id: 3, name: "Charlie", role: "Viewer", age: 25 },
];

export default function TableView() {
  const [data, setData] = useState(initialData);
  const [sortField, setSortField] = useState(null);
  const [asc, setAsc] = useState(true);

  const sortData = (field) => {
    const ascOrder = sortField === field ? !asc : true;
    setSortField(field);
    setAsc(ascOrder);
    const sorted = [...data].sort((a, b) => {
      if (a[field] < b[field]) return ascOrder ? -1 : 1;
      if (a[field] > b[field]) return ascOrder ? 1 : -1;
      return 0;
    });
    setData(sorted);
  };

  return (
    <table
      style={{
        width: "100%",
        borderCollapse: "collapse",
        backgroundColor: "var(--card-bg)",
      }}
    >
      <thead>
        <tr>
          {["id", "name", "role", "age"].map((field) => (
            <th
              key={field}
              onClick={() => sortData(field)}
              style={{
                borderBottom: "2px solid var(--text)",
                cursor: "pointer",
                padding: 10,
                userSelect: "none",
              }}
            >
              {field.toUpperCase()} {sortField === field ? (asc ? "▲" : "▼") : ""}
            </th>
          ))}
        </tr>
      </thead>
      <tbody>
        {data.map(({ id, name, role, age }) => (
          <tr key={id} style={{ borderBottom: "1px solid var(--text)" }}>
            <td style={{ padding: 10 }}>{id}</td>
            <td style={{ padding: 10 }}>{name}</td>
            <td style={{ padding: 10 }}>{role}</td>
            <td style={{ padding: 10 }}>{age}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
