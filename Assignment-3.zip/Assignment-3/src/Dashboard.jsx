import React from "react";
import { useTheme } from "./App";
import TableView from "./TableView";
import ChartView from "./ChartView";
import CalendarView from "./CalendarView";
import KanbanView from "./KanbanView";

export default function Dashboard() {
  const { theme, toggleTheme } = useTheme();

  return (
    <div style={{ padding: 20, maxWidth: 1200, margin: "auto" }}>
      <header style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <h1>React Admin Dashboard</h1>
        <button onClick={toggleTheme} style={{ padding: "8px 16px" }}>
          Switch to {theme === "light" ? "Dark" : "Light"} Theme
        </button>
      </header>

      <section style={{ marginTop: 30 }}>
        <h2>Data Table</h2>
        <TableView />
      </section>

      <section style={{ marginTop: 40 }}>
        <h2>Chart</h2>
        <ChartView />
      </section>

      <section style={{ marginTop: 40 }}>
        <h2>Calendar</h2>
        <CalendarView />
      </section>

      <section style={{ marginTop: 40, marginBottom: 40 }}>
        <h2>Kanban Board</h2>
        <KanbanView />
      </section>
    </div>
  );
}
