import React, { useState } from 'react';

export default function TodoApp() {
  const [task, setTask] = useState('');
  const [tasks, setTasks] = useState([]);

  const addTask = () => {
    const trimmedTask = task.trim();
    if (trimmedTask === '') return;

    const updatedTasks = [...tasks, trimmedTask];
    updatedTasks.sort((a, b) => a.localeCompare(b));
    setTasks(updatedTasks);
    setTask('');
  };

  const deleteTask = (indexToDelete) => {
    const updatedTasks = tasks.filter((_, index) => index !== indexToDelete);
    setTasks(updatedTasks);
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') addTask();
  };

  return (
    <div
      style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: '100vh',
        backgroundColor: '#1e1e1e',
        color: 'white',
      }}
    >
      <div style={{ textAlign: 'center' }}>
        <h2>To-Do List</h2>
        <input
          type="text"
          value={task}
          onChange={(e) => setTask(e.target.value)}
          onKeyDown={handleKeyPress}
          placeholder="Enter a task"
          style={{
            padding: '10px',
            marginRight: '10px',
            borderRadius: '4px',
            border: '1px solid #ccc',
          }}
        />
        <button
          onClick={addTask}
          style={{
            padding: '10px 20px',
            backgroundColor: '#000',
            color: '#fff',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer',
          }}
        >
          Add
        </button>

        <ul style={{ listStyleType: 'none', padding: 0, marginTop: '20px' }}>
          {tasks.map((t, index) => (
            <li
              key={index}
              style={{
                marginBottom: '10px',
                display: 'flex',
                justifyContent: 'space-between',
                backgroundColor: '#333',
                padding: '10px',
                borderRadius: '5px',
              }}
            >
              <span>{t}</span>
              <button
                onClick={() => deleteTask(index)}
                style={{
                  backgroundColor: '#e74c3c',
                  color: '#fff',
                  border: 'none',
                  padding: '5px 10px',
                  borderRadius: '3px',
                  cursor: 'pointer',
                }}
              >
                Delete
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
